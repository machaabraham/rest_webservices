<?php
require "../vendor/autoload.php";

// initialise leaf
$app = new Leaf\App;

app()->get('/', function() {
  echo "Hello there!";
});

// $app->get("/student", function() use($app) {
//   $unsorted_array = array(1,3,2,8,5,7,4,0,10,13,20,17,12,6,9);
//     $size = count($unsorted_array)-1;
//     for ($i=0; $i<$size; $i++) {
//         for ($j=0; $j<$size-$i; $j++) {
//             $k = $j+1;
//             if ($unsorted_array[$k] < $unsorted_array[$j]) {
//                 // Swap elements at indices: $j, $k
//               list($unsorted_array[$j],$unsorted_array[$k]) = array($unsorted_array[$k], $unsorted_array[$j]);
//             }
//         }
//     }
//     $sorted_array = $unsorted_array;
    
//     return $app->response()->json([
//     "message" => $sorted_array
//     ]);
// });
$app->post('/student', function() use($app) {
  // response is initialized with leaf
  $app->response()->json([
    "message" => "post"
  ]);
});

$app->put('/student', function() use($app) {
  // response is initialized with leaf
  $app->response()->json([
    "message" => "put"
  ]);
});
$app->delete('/student', function() use($app) {
  // response is initialized with leaf
  $app->response()->json([
    "message" => "delete"
  ]);
});
// run the defined routes
$app->run();

?>
