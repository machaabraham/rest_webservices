<?php
return array(
    'db' => ['servername'=>'localhost','user' => 'root', 'password' => 'password','db'=>'school_db']
);
?>