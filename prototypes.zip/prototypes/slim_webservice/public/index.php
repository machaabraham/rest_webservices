<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();

$app->get('/student', function (Request $request, Response $response, $args) {
    // Check connection
    $conn = new mysqli('localhost','root','password','school_db');

    if ($conn->connect_error) {
      $response->getBody()->write($conn->connect_error);
      return $response;
    }

    $sql = "SELECT * FROM student";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row
        while($row = $result->fetch_assoc()){
            $data[] = $row;
        }
        $response->getBody()->write(json_encode($data));

        return $response;
    } 
    if ($result->num_rows < 1) {
        $response->getBody(json_encode($result));
        echo $response;
    } 
    $conn->close();
   
});
// $app->get('/student/{id}', function (Request $request, Response $response, $args) {
//     // Check connection
//     $id=(int) $request->getQueryParams('id');
//     $conn = new mysqli('localhost','root','password','school_db');

//     if ($conn->connect_error) {
//       $response->getBody()->write($conn->connect_error);
//       return $response;
//     }

//     $sql = "SELECT * FROM student WHERE id=$id";
//     $result = $conn->query($sql);

//     if ($result->num_rows > 0) {
//     // output data of each row
//         $row = $result->fetch_assoc();
//         $all_students =json_encode($row);
//         $response->getBody()->write($all_students);
//     } 
//     if ($result->num_rows < 1) {
//         $response->getBody()->write("No students records");
//     } 
//     $conn->close();
//     return $response;
// });
$app->post('/student', function (Request $request, Response $response, $args) {
     // Check connection
     $conn = new mysqli('localhost','root','password','school_db');

     if ($conn->connect_error) {
       $response->getBody()->write($conn->connect_error);
       return $response;
     }
 
     for($i=0; $i < 100; $i++){
     $sql = "INSERT INTO student(first_name,middle_name,surname) VALUES('Abraham',$i,$i)";
     $conn->query($sql);
     }
    //$response->getBody()->write("true");
     $conn->close();
     //return $response;
     return true;
 
});
$app->put('/student', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Hello world!");
    return $response;
});
$app->delete('/student', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Hello world!");
    return $response;
});

$app->run();

