<?php
require '../vendor/autoload.php';
$f3 = \Base::instance();

class Student {
    function get() {
        
        $db=new DB\SQL(
            'mysql:host=localhost;port=3306;dbname=school_db',
            'root',
            'password');
           $results = $db->exec('SELECT * FROM student');
           header('Content-Type: application/json');
           echo json_encode($results);

    }
    function post() {
        $unsorted_array = array(1,3,2,8,5,7,4,0,10,13,20,17,12,6,9);
        $size = count($unsorted_array)-1;
        for ($i=0; $i<$size; $i++) {
            for ($j=0; $j<$size-$i; $j++) {
                $k = $j+1;
                if ($unsorted_array[$k] < $unsorted_array[$j]) {
                    // Swap elements at indices: $j, $k
                  list($unsorted_array[$j],$unsorted_array[$k]) = array($unsorted_array[$k], $unsorted_array[$j]);
                }
            }
        }
        $sorted_array = $unsorted_array;
        
        echo json_encode($sorted_array);
    }
    function put() {
     echo "Welcome PUT";
    }
    function delete() {
     echo "Welcome DELETE";
    }
}

$f3->map('/student','Student');
$f3->run();

?>
