<?php
namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;


class Student extends ResourceController{
    // all users
    public function index(){
        $db = \Config\Database::connect();
        $query = $db->query("SELECT * FROM student;");
        $result_array = $query->getResultArray();
        return json_encode($result_array);
    }

    // create
    public function create() {
        echo "welcome POST";
    }


    // update
    public function update($id = null){
        echo "Welcome PUT";
    }

    // delete
    public function delete($id = null){
        echo "Welcome DELETE";
    }
}